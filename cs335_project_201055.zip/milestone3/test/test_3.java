// Test Case 3 :: Conditional Statement

public class LargestNumberExample  
{  
public static void main(String args[])  
{  
int x=69;  
int y=89;  
int z=79;  
boolean res=z<y;
int largestNumber= res ? z : x;  
// System.out.println(largestNumber);  
}  
}

