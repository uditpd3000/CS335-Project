// Test Case 5 :: type casting


public class typeCast{
  public static void main(String[] args){
      byte a=1;
      short b=2;
      int c=3;
      long d=4;
      float e=5;
      double f=6;

      e=1*1.1;
      e=+1.1;
      ++f;
      f++;

      f=c;
      // c=f;

      // // Displaying the result
      System.out.println("Sum of two matrices is: ");
      // for(int row[] : sum1) {
      //     for (int column : row) {
      //         System.out.println("    ");
      //     }
      //     System.out.println("end");
      // }
  }
}

