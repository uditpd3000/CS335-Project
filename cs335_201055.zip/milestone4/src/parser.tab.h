/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

#ifndef YY_YY_PARSER_TAB_H_INCLUDED
# define YY_YY_PARSER_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 1
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token kinds.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    YYEMPTY = -2,
    YYEOF = 0,                     /* "end of file"  */
    YYerror = 256,                 /* error  */
    YYUNDEF = 257,                 /* "invalid token"  */
    curly_open = 258,              /* curly_open  */
    curly_close = 259,             /* curly_close  */
    class_access = 260,            /* class_access  */
    STATIC = 261,                  /* STATIC  */
    FINAL = 262,                   /* FINAL  */
    key_SEAL = 263,                /* key_SEAL  */
    key_abstract = 264,            /* key_abstract  */
    key_STRICTFP = 265,            /* key_STRICTFP  */
    field_modifier = 266,          /* field_modifier  */
    method_modifier = 267,         /* method_modifier  */
    box_open = 268,                /* box_open  */
    box_close = 269,               /* box_close  */
    dot = 270,                     /* dot  */
    dots = 271,                    /* dots  */
    less_than = 272,               /* less_than  */
    greater_than = 273,            /* greater_than  */
    comma = 274,                   /* comma  */
    ques_mark = 275,               /* ques_mark  */
    bitwise_and = 276,             /* bitwise_and  */
    at = 277,                      /* at  */
    colon = 278,                   /* colon  */
    OR = 279,                      /* OR  */
    brac_open = 280,               /* brac_open  */
    brac_close = 281,              /* brac_close  */
    bitwise_xor = 282,             /* bitwise_xor  */
    bitwise_or = 283,              /* bitwise_or  */
    assign = 284,                  /* assign  */
    semi_colon = 285,              /* semi_colon  */
    class_just_class = 286,        /* class_just_class  */
    literal_type = 287,            /* literal_type  */
    AssignmentOperator1 = 288,     /* AssignmentOperator1  */
    keyword = 289,                 /* keyword  */
    throws = 290,                  /* throws  */
    var = 291,                     /* var  */
    Identifier = 292,              /* Identifier  */
    extends = 293,                 /* extends  */
    super = 294,                   /* super  */
    implements = 295,              /* implements  */
    permits = 296,                 /* permits  */
    IMPORT = 297,                  /* IMPORT  */
    DOT_STAR = 298,                /* DOT_STAR  */
    ARITHMETIC_OP_ADDITIVE = 299,  /* ARITHMETIC_OP_ADDITIVE  */
    ARITHMETIC_OP_MULTIPLY = 300,  /* ARITHMETIC_OP_MULTIPLY  */
    LOGICAL_OP = 301,              /* LOGICAL_OP  */
    Equality_OP = 302,             /* Equality_OP  */
    INCR_DECR = 303,               /* INCR_DECR  */
    VOID = 304,                    /* VOID  */
    THIS = 305,                    /* THIS  */
    AND = 306,                     /* AND  */
    EQUALNOTEQUAL = 307,           /* EQUALNOTEQUAL  */
    SHIFT_OP = 308,                /* SHIFT_OP  */
    INSTANCE_OF = 309,             /* INSTANCE_OF  */
    RELATIONAL_OP1 = 310,          /* RELATIONAL_OP1  */
    NEW = 311,                     /* NEW  */
    THROW = 312,                   /* THROW  */
    RETURN = 313,                  /* RETURN  */
    CONTINUE = 314,                /* CONTINUE  */
    FOR = 315,                     /* FOR  */
    IF = 316,                      /* IF  */
    ELSE = 317,                    /* ELSE  */
    WHILE = 318,                   /* WHILE  */
    BREAK = 319,                   /* BREAK  */
    PRINTLN = 320,                 /* PRINTLN  */
    FloatingPoint = 321,           /* FloatingPoint  */
    BinaryInteger = 322,           /* BinaryInteger  */
    OctalInteger = 323,            /* OctalInteger  */
    HexInteger = 324,              /* HexInteger  */
    DecimalInteger = 325,          /* DecimalInteger  */
    NullLiteral = 326,             /* NullLiteral  */
    CharacterLiteral = 327,        /* CharacterLiteral  */
    TextBlock = 328,               /* TextBlock  */
    StringLiteral = 329,           /* StringLiteral  */
    BooleanLiteral = 330           /* BooleanLiteral  */
  };
  typedef enum yytokentype yytoken_kind_t;
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
union YYSTYPE
{
#line 121 "parser.y"

  char* sym;
  Node* node;

#line 144 "parser.tab.h"

};
typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;


int yyparse (void);


#endif /* !YY_YY_PARSER_TAB_H_INCLUDED  */
